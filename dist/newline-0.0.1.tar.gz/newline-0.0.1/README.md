# NewLine
Newline Project Initiative
This is a project to help python programmers to store data in text file under CSV format.
Please make sure that all input for writing in a file is in list[list].
All the data to read and write is in CSV format.
In list[list] format list[0] is the first line list[1] is the second line and from this on forward.
You can open and edit all files created in excel.
This Project has just started and will be updated constantly

GitHub for this project - https://github.com/Ayush-sharma-py/NewLine.git